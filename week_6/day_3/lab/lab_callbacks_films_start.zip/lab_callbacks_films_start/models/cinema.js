const Cinema = function (films) {
  this.films = films;
};

module.exports = Cinema;
